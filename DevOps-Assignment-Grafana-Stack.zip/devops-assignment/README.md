# DevOps Assignment: Grafana + Loki + Promtail pipeline

## What this contains
- Loki for log storage and queries
- Promtail to collect logs and add labels/transformations
- Grafana for dashboards and filters
- Log generator that replays the sample JSON logs into a file Promtail scrapes
- Provisioning so Grafana has a ready-to-use Loki data source and starter dashboard

## Run (local)
1. Install Docker and Docker Compose.
2. In this folder, run: `docker compose up -d`
3. Open Grafana at http://localhost:3000 (user: `admin`, pass: `admin`).
4. Open the **Robot Logs (Loki)** dashboard. Use the filters at the top:
   - instrumentation_scope (multi-select)
   - severity_text (multi-select)
   - observed_timestamp_rfc3339 contains (free text substring)
5. To stop: `docker compose down`

## Files to check
- `promtail-config.yml`: JSON parsing, timestamp mapping, and label selection.
- `grafana/provisioning/dashboards/robot_logs.json`: dashboard with filters and panels.
- `log-generator/`: Dockerfile and script that writes sample logs at a controlled rate.

## CI/CD (example)
See `.github/workflows/ci.yml` for a simple build-and-deploy idea. Replace placeholders:
- `ghcr.io/ORG/robot-loggen:latest` -> your image path
- Set repository secrets: `SSH_HOST`, `SSH_USER`, `SSH_KEY`
On push to `main`, it builds/pushes the log generator image, then deploys by SSH to a Docker host and runs `docker compose up -d`.
