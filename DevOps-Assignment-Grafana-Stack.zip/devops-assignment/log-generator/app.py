import os, time

LOG_PATH = os.environ.get("LOG_PATH", "/logs/robot.log")
RATE = float(os.environ.get("RATE", "1"))  # lines per second
sample_path = os.path.join(os.path.dirname(__file__), "sample.jsonl")

os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

def stream_lines():
    with open(sample_path, "r", encoding="utf-8") as f:
        lines = [ln.rstrip("\n") for ln in f if ln.strip()]
    i = 0
    while True:
        line = lines[i % len(lines)]
        with open(LOG_PATH, "a", encoding="utf-8") as out:
            out.write(line + "\n")
        i += 1
        time.sleep(1.0 / RATE)

if __name__ == "__main__":
    print(f"[loggen] Writing to {LOG_PATH} at RATE={RATE} lines/sec", flush=True)
    try:
        stream_lines()
    except KeyboardInterrupt:
        print("[loggen] Stopped", flush=True)
